java -jar weka-imsofa.jar
